// Export all new section components
export { default as CollectionsSection } from './CollectionsSection';
export { default as PriceCalculatorSection } from './PriceCalculatorSection';
export { default as PopularProductsSection } from './PopularProductsSection';
