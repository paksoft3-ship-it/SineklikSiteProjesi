# Window Specialist - Website Updates

This update includes all the requested features:
1. **User Signup/Login System** with account dashboard
2. **RAG-based Chatbot** with website knowledge
3. **Testimonials Slider** with auto-play
4. **Plissé Animation** with wave/fold effects
5. **Social Media Links** in footer
6. **Contact Information** in footer
7. **Fixed Header Dropdown** navigation

## 📦 Files Included

```
src/
├── context/
│   └── AuthContext.tsx              # User authentication state
├── components/
│   ├── auth/
│   │   ├── AuthModal.tsx            # Login/Signup modal
│   │   ├── UserDropdown.tsx         # Logged-in user dropdown
│   │   └── index.ts
│   ├── chatbot/
│   │   ├── Chatbot.tsx              # RAG chatbot component
│   │   └── index.ts
│   ├── testimonials/
│   │   ├── TestimonialsSlider.tsx   # Reviews slider
│   │   └── index.ts
│   ├── animations/
│   │   ├── PlisseAnimation.tsx      # Curtain wave animation
│   │   └── index.ts
│   └── layout/
│       ├── Header.tsx               # Fixed dropdown navigation
│       ├── Footer.tsx               # Social + Contact info
│       └── index.ts
├── styles/
│   └── animations.css               # All custom animations
└── app/(main)/
    └── account/
        └── page.tsx                 # User dashboard page
```

## 🚀 Features

### 1. User Authentication System
- **Login/Signup Modal**: Email/password authentication
- **User Dropdown**: Shows orders, shipping status, account settings
- **Account Dashboard**: View orders, manage profile, track shipments
- **Session Persistence**: LocalStorage-based (replace with your backend)

### 2. RAG Chatbot
- **Knowledge Base**: Products, services, FAQ, contact info
- **Smart Search**: Matches user queries to relevant content
- **Source Attribution**: Shows where information came from
- **Quick Actions**: Pre-defined question buttons
- **Typing Indicator**: Simulated typing effect

### 3. Testimonials Slider
- **Auto-play**: 5-second intervals
- **Pause on Hover**: User-controlled
- **Responsive**: 1 card on mobile, 3 on desktop
- **Smooth Transitions**: CSS animations
- **Dot Navigation**: Click to jump to slide

### 4. Plissé Animation
- **Wave Effect**: Horizontal lines animation on slide change
- **Pleated Overlay**: Subtle fabric texture
- **Fold Shadows**: 3D-like depth effect
- **Auto-play**: Configurable interval
- **Navigation**: Arrows and dots

### 5. Fixed Header Dropdown
- **No Gap Issue**: Invisible bridge element prevents flickering
- **Delay on Close**: 150ms delay allows mouse movement
- **Mobile Support**: Accordion-style on mobile
- **Badges**: Product popularity indicators

### 6. Footer Updates
- **Social Links**: Facebook, Instagram, LinkedIn, Pinterest, YouTube, WhatsApp
- **Contact Info**: Address, phone, email, hours
- **Trust Badges**: Shipping, warranty, custom-made, support
- **Newsletter**: Email subscription form
- **Payment Methods**: iDEAL, Visa, Mastercard, etc.

## 🔧 Integration

### Step 1: Copy Files
```bash
unzip website-updates.zip
cp -r website-updates/src/* your-project/src/
```

### Step 2: Import CSS
Add to your `globals.css`:
```css
@import './styles/animations.css';
```

Or add animations to `tailwind.config.js`:
```js
module.exports = {
  theme: {
    extend: {
      animation: {
        fadeIn: 'fadeIn 0.3s ease-out',
        slideUp: 'slideUp 0.4s ease-out',
        bounce: 'bounce 0.6s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(-10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        bounce: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-4px)' },
        },
      },
    },
  },
}
```

### Step 3: Wrap App with AuthProvider
In your `layout.tsx`:
```tsx
import { AuthProvider } from '@/context/AuthContext';

export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        <AuthProvider>
          <Header />
          {children}
          <Footer />
          <Chatbot />
        </AuthProvider>
      </body>
    </html>
  );
}
```

### Step 4: Use Components

**Testimonials on Homepage:**
```tsx
import { TestimonialsSlider } from '@/components/testimonials';

<TestimonialsSlider />
```

**Plissé Animation for Product Gallery:**
```tsx
import { PlisseAnimation } from '@/components/animations';

<PlisseAnimation 
  images={['/img1.jpg', '/img2.jpg', '/img3.jpg']}
  autoPlay={true}
  interval={5000}
/>
```

## 🎨 Customization

### Chatbot Knowledge Base
Edit the `knowledgeBase` object in `Chatbot.tsx`:
```tsx
const knowledgeBase = {
  products: { ... },
  services: { ... },
  contact: { ... },
  faq: [ ... ],
};
```

### Social Links
Edit the `socialLinks` array in `Footer.tsx`:
```tsx
const socialLinks = [
  { name: 'Facebook', icon: 'fab fa-facebook-f', href: 'YOUR_URL' },
  // ...
];
```

### Contact Information
Edit the contact details in `Footer.tsx`:
```tsx
// Address
<p>Herengracht 123</p>
<p>1015 BK Amsterdam</p>

// Phone
<a href="tel:+31201234567">+31 (0)20 123 4567</a>

// Email
<a href="mailto:info@windowspecialist.nl">info@windowspecialist.nl</a>
```

### Testimonials
Edit the `testimonials` array in `TestimonialsSlider.tsx`:
```tsx
const testimonials = [
  {
    id: 1,
    name: 'Customer Name',
    location: 'City',
    rating: 5,
    text: 'Review text...',
    product: 'Product Name',
    date: 'December 2024',
  },
  // ...
];
```

## 🔒 Authentication Notes

The current implementation uses localStorage for demo purposes. For production:

1. Replace localStorage with your backend API calls
2. Implement JWT token management
3. Add proper password hashing
4. Implement OAuth providers (Google, etc.)

Example API integration:
```tsx
const login = async (email: string, password: string) => {
  const response = await fetch('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });
  const data = await response.json();
  if (data.success) {
    setUser(data.user);
    localStorage.setItem('token', data.token);
  }
  return data.success;
};
```

## 🤖 Chatbot RAG Enhancement

For more advanced RAG capabilities:

1. **Vector Database**: Use Pinecone, Weaviate, or ChromaDB
2. **Embeddings**: Use OpenAI embeddings or sentence-transformers
3. **LLM Integration**: Connect to GPT-4, Claude, or local models

Example with OpenAI:
```tsx
const searchKnowledge = async (query: string) => {
  // 1. Generate embedding
  const embedding = await openai.embeddings.create({
    model: 'text-embedding-3-small',
    input: query,
  });
  
  // 2. Search vector database
  const results = await vectorDb.query(embedding);
  
  // 3. Generate response with context
  const response = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [
      { role: 'system', content: `Answer based on: ${results.join('\n')}` },
      { role: 'user', content: query },
    ],
  });
  
  return response.choices[0].message.content;
};
```

## 📱 Responsive Design

All components are fully responsive:
- **Mobile**: Single column, accordion navigation
- **Tablet**: Two columns where appropriate
- **Desktop**: Full multi-column layouts

## 🎯 Browser Support

- Chrome 80+
- Firefox 75+
- Safari 13+
- Edge 80+

## 📝 License

MIT License - Feel free to use and modify.
