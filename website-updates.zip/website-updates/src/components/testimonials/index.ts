export { default as TestimonialsSlider } from './TestimonialsSlider';
