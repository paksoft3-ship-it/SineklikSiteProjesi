'use client';

import Link from 'next/link';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    { name: 'Facebook', icon: 'fab fa-facebook-f', href: 'https://facebook.com/windowspecialist', color: 'hover:bg-blue-600' },
    { name: 'Instagram', icon: 'fab fa-instagram', href: 'https://instagram.com/windowspecialist', color: 'hover:bg-pink-600' },
    { name: 'LinkedIn', icon: 'fab fa-linkedin-in', href: 'https://linkedin.com/company/windowspecialist', color: 'hover:bg-blue-700' },
    { name: 'Pinterest', icon: 'fab fa-pinterest-p', href: 'https://pinterest.com/windowspecialist', color: 'hover:bg-red-600' },
    { name: 'YouTube', icon: 'fab fa-youtube', href: 'https://youtube.com/windowspecialist', color: 'hover:bg-red-500' },
    { name: 'WhatsApp', icon: 'fab fa-whatsapp', href: 'https://wa.me/31201234567', color: 'hover:bg-green-500' },
  ];

  const plisseHorrenLinks = [
    { name: 'Plissé Hordeur', href: '/producten/plisse-horren/deur' },
    { name: 'Plissé Raamhor', href: '/producten/plisse-horren/raam' },
    { name: 'Glazen Balkon Hor', href: '/producten/plisse-horren/glazen-balkon' },
    { name: 'Drempelloze Hor', href: '/producten/plisse-horren/drempelloos' },
    { name: 'Hor + Gordijn Combi', href: '/producten/plisse-horren/hor-gordijn-combinatie' },
  ];

  const plisseGordijnenLinks = [
    { name: 'Honeycomb / Duette', href: '/producten/plisse-gordijnen/honeycomb' },
    { name: 'Verduisterend', href: '/producten/plisse-gordijnen/verduisterend' },
    { name: 'Lichtdoorlatend', href: '/producten/plisse-gordijnen/lichtdoorlatend' },
    { name: 'Kleuropties', href: '/producten/plisse-gordijnen/kleuropties' },
  ];

  const serviceLinks = [
    { name: 'Gratis Stalen', href: '/stalen' },
    { name: 'Meetgids', href: '/meetgids' },
    { name: 'Montageservice', href: '/montage' },
    { name: 'Veelgestelde Vragen', href: '/faq' },
    { name: 'Reviews', href: '/reviews' },
  ];

  const legalLinks = [
    { name: 'Algemene Voorwaarden', href: '/voorwaarden' },
    { name: 'Privacybeleid', href: '/privacy' },
    { name: 'Cookiebeleid', href: '/cookies' },
    { name: 'Retourbeleid', href: '/retour' },
  ];

  return (
    <footer className="bg-secondary dark:bg-gray-900">
      {/* Trust Badges */}
      <div className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                <i className="fas fa-truck text-xl text-primary"></i>
              </div>
              <div className="text-white">
                <p className="font-semibold">Gratis Verzending</p>
                <p className="text-sm text-gray-400">Vanaf €50</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                <i className="fas fa-shield-alt text-xl text-primary"></i>
              </div>
              <div className="text-white">
                <p className="font-semibold">5 Jaar Garantie</p>
                <p className="text-sm text-gray-400">Op alle producten</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                <i className="fas fa-ruler text-xl text-primary"></i>
              </div>
              <div className="text-white">
                <p className="font-semibold">Op Maat Gemaakt</p>
                <p className="text-sm text-gray-400">Perfect passend</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                <i className="fas fa-headset text-xl text-primary"></i>
              </div>
              <div className="text-white">
                <p className="font-semibold">Expert Support</p>
                <p className="text-sm text-gray-400">Ma-Za bereikbaar</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8">
          {/* Company Info & Contact */}
          <div className="lg:col-span-2">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <i className="fas fa-window-maximize text-white"></i>
              </div>
              <span className="font-display font-bold text-xl text-white">
                Window<span className="text-primary">Specialist</span>
              </span>
            </Link>

            <p className="text-gray-400 text-sm mb-6">
              Specialist in hoogwaardige plissé horren en gordijnen op maat. 
              Meer dan 15.000 tevreden klanten in heel Nederland.
            </p>

            {/* Contact Info */}
            <div className="space-y-3 mb-6">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-map-marker-alt text-primary text-sm"></i>
                </div>
                <div className="text-gray-400 text-sm">
                  <p className="text-white font-medium">Bezoekadres</p>
                  <p>Herengracht 123</p>
                  <p>1015 BK Amsterdam</p>
                  <p>Nederland</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-phone text-primary text-sm"></i>
                </div>
                <div className="text-gray-400 text-sm">
                  <p className="text-white font-medium">Telefoon</p>
                  <a href="tel:+31201234567" className="hover:text-primary transition">
                    +31 (0)20 123 4567
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-envelope text-primary text-sm"></i>
                </div>
                <div className="text-gray-400 text-sm">
                  <p className="text-white font-medium">E-mail</p>
                  <a href="mailto:info@windowspecialist.nl" className="hover:text-primary transition">
                    info@windowspecialist.nl
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-clock text-primary text-sm"></i>
                </div>
                <div className="text-gray-400 text-sm">
                  <p className="text-white font-medium">Openingstijden</p>
                  <p>Ma - Vr: 09:00 - 18:00</p>
                  <p>Za: 10:00 - 17:00</p>
                </div>
              </div>
            </div>

            {/* Social Links */}
            <div>
              <p className="text-white font-medium mb-3">Volg ons</p>
              <div className="flex flex-wrap gap-2">
                {socialLinks.map((social) => (
                  <a
                    key={social.name}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center text-gray-400 transition-all duration-300 ${social.color} hover:text-white hover:scale-110`}
                    title={social.name}
                  >
                    <i className={social.icon}></i>
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Plissé Horren */}
          <div>
            <h4 className="text-white font-semibold mb-4">Plissé Horren</h4>
            <ul className="space-y-2">
              {plisseHorrenLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-gray-400 text-sm hover:text-primary transition flex items-center gap-2"
                  >
                    <i className="fas fa-chevron-right text-xs text-primary/50"></i>
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Plissé Gordijnen */}
          <div>
            <h4 className="text-white font-semibold mb-4">Plissé Gordijnen</h4>
            <ul className="space-y-2">
              {plisseGordijnenLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-gray-400 text-sm hover:text-primary transition flex items-center gap-2"
                  >
                    <i className="fas fa-chevron-right text-xs text-primary/50"></i>
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Service */}
          <div>
            <h4 className="text-white font-semibold mb-4">Service</h4>
            <ul className="space-y-2">
              {serviceLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-gray-400 text-sm hover:text-primary transition flex items-center gap-2"
                  >
                    <i className="fas fa-chevron-right text-xs text-primary/50"></i>
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter & Reviews */}
          <div>
            <h4 className="text-white font-semibold mb-4">Nieuwsbrief</h4>
            <p className="text-gray-400 text-sm mb-4">
              Ontvang exclusieve aanbiedingen en tips.
            </p>
            <form className="space-y-2">
              <input
                type="email"
                placeholder="Uw e-mailadres"
                className="w-full px-4 py-2 bg-white/10 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent text-sm"
              />
              <button
                type="submit"
                className="w-full px-4 py-2 bg-primary hover:bg-blue-600 text-white font-medium rounded-lg transition text-sm"
              >
                Aanmelden
              </button>
            </form>

            {/* Review Score */}
            <div className="mt-6 p-4 bg-white/5 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <i key={i} className="fas fa-star text-sm"></i>
                  ))}
                </div>
                <span className="text-white font-bold">4.8/5</span>
              </div>
              <p className="text-gray-400 text-xs">
                Gebaseerd op 4.721 reviews
              </p>
              <div className="flex items-center gap-2 mt-2">
                <img src="https://www.google.com/favicon.ico" alt="Google" className="w-4 h-4" />
                <img src="https://www.trustpilot.com/favicon.ico" alt="Trustpilot" className="w-4 h-4" />
                <span className="text-gray-500 text-xs">Geverifieerd</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Methods */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <span className="text-gray-400 text-sm">Betaalmethoden:</span>
              <div className="flex items-center gap-2">
                <div className="w-10 h-6 bg-white/10 rounded flex items-center justify-center">
                  <i className="fab fa-ideal text-primary"></i>
                </div>
                <div className="w-10 h-6 bg-white/10 rounded flex items-center justify-center">
                  <i className="fab fa-cc-visa text-blue-400"></i>
                </div>
                <div className="w-10 h-6 bg-white/10 rounded flex items-center justify-center">
                  <i className="fab fa-cc-mastercard text-orange-400"></i>
                </div>
                <div className="w-10 h-6 bg-white/10 rounded flex items-center justify-center">
                  <i className="fab fa-cc-amex text-blue-300"></i>
                </div>
                <div className="w-10 h-6 bg-white/10 rounded flex items-center justify-center">
                  <i className="fab fa-paypal text-blue-500"></i>
                </div>
                <div className="w-10 h-6 bg-white/10 rounded flex items-center justify-center text-green-400 text-xs font-bold">
                  B
                </div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-gray-400 text-sm">Verzending:</span>
              <div className="flex items-center gap-2">
                <div className="w-10 h-6 bg-white/10 rounded flex items-center justify-center">
                  <i className="fas fa-truck text-primary text-xs"></i>
                </div>
                <span className="text-gray-400 text-xs">PostNL</span>
                <div className="w-10 h-6 bg-white/10 rounded flex items-center justify-center">
                  <i className="fas fa-shipping-fast text-yellow-400 text-xs"></i>
                </div>
                <span className="text-gray-400 text-xs">DHL</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-4 text-gray-400 text-sm">
              <span>© {currentYear} Window Specialist. Alle rechten voorbehouden.</span>
              <span className="hidden md:inline">|</span>
              <span>KvK: 12345678</span>
              <span>|</span>
              <span>BTW: NL123456789B01</span>
            </div>
            <div className="flex items-center gap-4">
              {legalLinks.map((link, index) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="text-gray-400 text-sm hover:text-primary transition"
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
