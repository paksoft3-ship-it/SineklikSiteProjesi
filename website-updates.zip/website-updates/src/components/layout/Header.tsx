'use client';

import { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';
import AuthModal from '@/components/auth/AuthModal';
import UserDropdown from '@/components/auth/UserDropdown';

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const dropdownTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  const { isAuthenticated, isLoading } = useAuth();

  const plisseHorrenProducts = [
    { name: 'Plissé Hordeur', href: '/producten/plisse-horren/deur', badge: 'Populair', badgeColor: 'bg-blue-500' },
    { name: 'Plissé Raamhor', href: '/producten/plisse-horren/raam' },
    { name: 'Glazen Balkon Hor', href: '/producten/plisse-horren/glazen-balkon', badge: 'Premium', badgeColor: 'bg-purple-500' },
    { name: 'Vaste Plissé Hor', href: '/producten/plisse-horren/vaste-hor', badge: 'Budget', badgeColor: 'bg-green-500' },
    { name: 'Binnenmontage Hor', href: '/producten/plisse-horren/binnenmontage' },
    { name: 'Hor + Gordijn Combi', href: '/producten/plisse-horren/hor-gordijn-combinatie', badge: 'Bestseller', badgeColor: 'bg-yellow-500' },
    { name: 'Drempelloze Hor', href: '/producten/plisse-horren/drempelloos' },
  ];

  const plisseGordijnenProducts = [
    { name: 'Honeycomb / Duette', href: '/producten/plisse-gordijnen/honeycomb', badge: 'Bestseller', badgeColor: 'bg-yellow-500' },
    { name: 'Verduisterend', href: '/producten/plisse-gordijnen/verduisterend', badge: 'Populair', badgeColor: 'bg-blue-500' },
    { name: 'Lichtdoorlatend (70%)', href: '/producten/plisse-gordijnen/lichtdoorlatend' },
    { name: 'Kleuropties & Stalen', href: '/producten/plisse-gordijnen/kleuropties', badge: 'Gratis', badgeColor: 'bg-green-500' },
  ];

  // Handle dropdown with delay to prevent flickering
  const handleMouseEnter = (dropdown: string) => {
    if (dropdownTimeoutRef.current) {
      clearTimeout(dropdownTimeoutRef.current);
    }
    setActiveDropdown(dropdown);
  };

  const handleMouseLeave = () => {
    dropdownTimeoutRef.current = setTimeout(() => {
      setActiveDropdown(null);
    }, 150); // Small delay to allow moving to dropdown
  };

  const openAuthModal = (mode: 'login' | 'signup') => {
    setAuthMode(mode);
    setIsAuthModalOpen(true);
  };

  return (
    <>
      <header className="bg-white dark:bg-gray-900 shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <i className="fas fa-window-maximize text-white"></i>
              </div>
              <span className="font-display font-bold text-xl text-secondary dark:text-white">
                Window<span className="text-primary">Specialist</span>
              </span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-1">
              {/* Plissé Horren Dropdown */}
              <div
                className="relative"
                onMouseEnter={() => handleMouseEnter('horren')}
                onMouseLeave={handleMouseLeave}
              >
                <button className="flex items-center gap-1 px-4 py-6 text-gray-700 dark:text-gray-300 hover:text-primary transition font-medium">
                  Plissé Horren
                  <i className={`fas fa-chevron-down text-xs transition-transform ${activeDropdown === 'horren' ? 'rotate-180' : ''}`}></i>
                </button>
                
                {/* Dropdown - Connected to trigger with pt-0 and negative margin */}
                <div
                  className={`absolute top-full left-0 w-72 bg-white dark:bg-gray-800 rounded-b-2xl shadow-2xl border border-gray-200 dark:border-gray-700 border-t-0 transition-all duration-200 ${
                    activeDropdown === 'horren' 
                      ? 'opacity-100 visible translate-y-0' 
                      : 'opacity-0 invisible -translate-y-2'
                  }`}
                  onMouseEnter={() => handleMouseEnter('horren')}
                  onMouseLeave={handleMouseLeave}
                >
                  {/* Invisible bridge to prevent gap */}
                  <div className="absolute -top-6 left-0 right-0 h-6 bg-transparent" />
                  
                  <div className="p-4">
                    <div className="flex items-center gap-2 mb-3 pb-3 border-b border-gray-100 dark:border-gray-700">
                      <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-bug text-primary"></i>
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900 dark:text-white text-sm">Insectenwering</p>
                        <p className="text-xs text-gray-500">7 producten</p>
                      </div>
                    </div>
                    <div className="space-y-1">
                      {plisseHorrenProducts.map((product) => (
                        <Link
                          key={product.href}
                          href={product.href}
                          className="flex items-center justify-between px-3 py-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition group"
                          onClick={() => setActiveDropdown(null)}
                        >
                          <span className="text-sm text-gray-700 dark:text-gray-300 group-hover:text-primary">
                            {product.name}
                          </span>
                          {product.badge && (
                            <span className={`px-2 py-0.5 text-xs font-medium text-white rounded-full ${product.badgeColor}`}>
                              {product.badge}
                            </span>
                          )}
                        </Link>
                      ))}
                    </div>
                    <Link
                      href="/producten/plisse-horren"
                      className="flex items-center justify-center gap-2 mt-3 pt-3 border-t border-gray-100 dark:border-gray-700 text-primary text-sm font-medium hover:underline"
                      onClick={() => setActiveDropdown(null)}
                    >
                      Bekijk alle horren <i className="fas fa-arrow-right text-xs"></i>
                    </Link>
                  </div>
                </div>
              </div>

              {/* Plissé Gordijnen Dropdown */}
              <div
                className="relative"
                onMouseEnter={() => handleMouseEnter('gordijnen')}
                onMouseLeave={handleMouseLeave}
              >
                <button className="flex items-center gap-1 px-4 py-6 text-gray-700 dark:text-gray-300 hover:text-primary transition font-medium">
                  Plissé Gordijnen
                  <i className={`fas fa-chevron-down text-xs transition-transform ${activeDropdown === 'gordijnen' ? 'rotate-180' : ''}`}></i>
                </button>
                
                <div
                  className={`absolute top-full left-0 w-72 bg-white dark:bg-gray-800 rounded-b-2xl shadow-2xl border border-gray-200 dark:border-gray-700 border-t-0 transition-all duration-200 ${
                    activeDropdown === 'gordijnen' 
                      ? 'opacity-100 visible translate-y-0' 
                      : 'opacity-0 invisible -translate-y-2'
                  }`}
                  onMouseEnter={() => handleMouseEnter('gordijnen')}
                  onMouseLeave={handleMouseLeave}
                >
                  {/* Invisible bridge */}
                  <div className="absolute -top-6 left-0 right-0 h-6 bg-transparent" />
                  
                  <div className="p-4">
                    <div className="flex items-center gap-2 mb-3 pb-3 border-b border-gray-100 dark:border-gray-700">
                      <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-sun text-primary"></i>
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900 dark:text-white text-sm">Zonwering</p>
                        <p className="text-xs text-gray-500">4 producten</p>
                      </div>
                    </div>
                    <div className="space-y-1">
                      {plisseGordijnenProducts.map((product) => (
                        <Link
                          key={product.href}
                          href={product.href}
                          className="flex items-center justify-between px-3 py-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition group"
                          onClick={() => setActiveDropdown(null)}
                        >
                          <span className="text-sm text-gray-700 dark:text-gray-300 group-hover:text-primary">
                            {product.name}
                          </span>
                          {product.badge && (
                            <span className={`px-2 py-0.5 text-xs font-medium text-white rounded-full ${product.badgeColor}`}>
                              {product.badge}
                            </span>
                          )}
                        </Link>
                      ))}
                    </div>
                    <Link
                      href="/producten/plisse-gordijnen"
                      className="flex items-center justify-center gap-2 mt-3 pt-3 border-t border-gray-100 dark:border-gray-700 text-primary text-sm font-medium hover:underline"
                      onClick={() => setActiveDropdown(null)}
                    >
                      Bekijk alle gordijnen <i className="fas fa-arrow-right text-xs"></i>
                    </Link>
                  </div>
                </div>
              </div>

              <Link href="/stalen" className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:text-primary transition font-medium">
                Gratis Stalen
              </Link>
              <Link href="/meetgids" className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:text-primary transition font-medium">
                Meetgids
              </Link>
              <Link href="/contact" className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:text-primary transition font-medium">
                Contact
              </Link>
            </nav>

            {/* Right Side - Auth & Cart */}
            <div className="flex items-center gap-3">
              {/* Auth Section */}
              {isLoading ? (
                <div className="w-8 h-8 bg-gray-200 rounded-full animate-pulse"></div>
              ) : isAuthenticated ? (
                <UserDropdown />
              ) : (
                <div className="hidden md:flex items-center gap-2">
                  <button
                    onClick={() => openAuthModal('login')}
                    className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:text-primary transition font-medium"
                  >
                    Inloggen
                  </button>
                  <button
                    onClick={() => openAuthModal('signup')}
                    className="px-4 py-2 bg-primary hover:bg-blue-600 text-white font-medium rounded-lg transition"
                  >
                    Registreren
                  </button>
                </div>
              )}

              {/* Cart */}
              <Link
                href="/winkelwagen"
                className="relative w-10 h-10 flex items-center justify-center rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition"
              >
                <i className="fas fa-shopping-cart text-gray-600 dark:text-gray-400"></i>
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-primary text-white text-xs font-bold rounded-full flex items-center justify-center">
                  0
                </span>
              </Link>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="lg:hidden w-10 h-10 flex items-center justify-center rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition"
              >
                <i className={`fas ${isMobileMenuOpen ? 'fa-times' : 'fa-bars'} text-gray-600 dark:text-gray-400`}></i>
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 animate-fadeIn">
            <div className="max-w-7xl mx-auto px-4 py-4 space-y-4">
              {/* Mobile Auth */}
              {!isAuthenticated && (
                <div className="flex gap-2 pb-4 border-b border-gray-200 dark:border-gray-700">
                  <button
                    onClick={() => {
                      openAuthModal('login');
                      setIsMobileMenuOpen(false);
                    }}
                    className="flex-1 py-2 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-700 dark:text-gray-300 font-medium"
                  >
                    Inloggen
                  </button>
                  <button
                    onClick={() => {
                      openAuthModal('signup');
                      setIsMobileMenuOpen(false);
                    }}
                    className="flex-1 py-2 bg-primary text-white rounded-lg font-medium"
                  >
                    Registreren
                  </button>
                </div>
              )}

              {/* Mobile Plissé Horren */}
              <div>
                <button
                  onClick={() => setActiveDropdown(activeDropdown === 'mobile-horren' ? null : 'mobile-horren')}
                  className="flex items-center justify-between w-full py-2 text-gray-700 dark:text-gray-300 font-medium"
                >
                  Plissé Horren
                  <i className={`fas fa-chevron-down text-xs transition-transform ${activeDropdown === 'mobile-horren' ? 'rotate-180' : ''}`}></i>
                </button>
                {activeDropdown === 'mobile-horren' && (
                  <div className="pl-4 mt-2 space-y-2">
                    {plisseHorrenProducts.map((product) => (
                      <Link
                        key={product.href}
                        href={product.href}
                        className="flex items-center justify-between py-2 text-sm text-gray-600 dark:text-gray-400"
                        onClick={() => setIsMobileMenuOpen(false)}
                      >
                        {product.name}
                        {product.badge && (
                          <span className={`px-2 py-0.5 text-xs font-medium text-white rounded-full ${product.badgeColor}`}>
                            {product.badge}
                          </span>
                        )}
                      </Link>
                    ))}
                  </div>
                )}
              </div>

              {/* Mobile Plissé Gordijnen */}
              <div>
                <button
                  onClick={() => setActiveDropdown(activeDropdown === 'mobile-gordijnen' ? null : 'mobile-gordijnen')}
                  className="flex items-center justify-between w-full py-2 text-gray-700 dark:text-gray-300 font-medium"
                >
                  Plissé Gordijnen
                  <i className={`fas fa-chevron-down text-xs transition-transform ${activeDropdown === 'mobile-gordijnen' ? 'rotate-180' : ''}`}></i>
                </button>
                {activeDropdown === 'mobile-gordijnen' && (
                  <div className="pl-4 mt-2 space-y-2">
                    {plisseGordijnenProducts.map((product) => (
                      <Link
                        key={product.href}
                        href={product.href}
                        className="flex items-center justify-between py-2 text-sm text-gray-600 dark:text-gray-400"
                        onClick={() => setIsMobileMenuOpen(false)}
                      >
                        {product.name}
                        {product.badge && (
                          <span className={`px-2 py-0.5 text-xs font-medium text-white rounded-full ${product.badgeColor}`}>
                            {product.badge}
                          </span>
                        )}
                      </Link>
                    ))}
                  </div>
                )}
              </div>

              <Link
                href="/stalen"
                className="block py-2 text-gray-700 dark:text-gray-300 font-medium"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Gratis Stalen
              </Link>
              <Link
                href="/meetgids"
                className="block py-2 text-gray-700 dark:text-gray-300 font-medium"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Meetgids
              </Link>
              <Link
                href="/contact"
                className="block py-2 text-gray-700 dark:text-gray-300 font-medium"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Contact
              </Link>
            </div>
          </div>
        )}
      </header>

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        initialMode={authMode}
      />
    </>
  );
};

export default Header;
